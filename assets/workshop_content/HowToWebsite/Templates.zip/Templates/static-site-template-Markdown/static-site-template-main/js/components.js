/* =============================================================
   COMPONENTS.JS — Reusable Component Injection
   =============================================================
   This script loads shared HTML snippets (navbar, footer) from
   the /components/ folder and injects them into placeholder
   elements on each page.

   HOW IT WORKS:
   1. On every page you add:
        <div id="navbar-placeholder"></div>   (where the nav goes)
        <div id="footer-placeholder"></div>   (where the footer goes)
   2. This script fetches the HTML files and drops them in.
   3. After injection it wires up the mobile-menu toggle,
      highlights the active page link, and sets the copyright year.

   WHY?  You only edit navbar.html or footer.html ONCE and the
   change appears on every page that includes this script.
   ============================================================= */


/**
 * loadComponent()
 * ----------------
 * Fetches an HTML snippet and injects it into a placeholder element.
 *
 * @param {string} placeholderId – The id of the target <div>.
 * @param {string} filePath      – Relative path to the HTML snippet.
 * @returns {Promise<void>}
 */
async function loadComponent(placeholderId, filePath) {
  const placeholder = document.getElementById(placeholderId);

  // Safety check — skip if the placeholder doesn't exist on this page
  if (!placeholder) return;

  try {
    const response = await fetch(filePath);

    if (!response.ok) {
      throw new Error(`Failed to load ${filePath}: ${response.status}`);
    }

    // Insert the fetched HTML into the placeholder
    placeholder.innerHTML = await response.text();

  } catch (error) {
    console.error(`[components.js] ${error.message}`);
  }
}


/**
 * initNavbar()
 * ----------------
 * Wires up the mobile hamburger menu toggle and highlights
 * the active page link based on the current URL.
 * Called after the navbar HTML has been injected.
 */
function initNavbar() {
  const toggle = document.getElementById('nav-toggle');
  const links  = document.getElementById('nav-links');

  if (!toggle || !links) return;

  // --- Mobile menu toggle ---
  toggle.addEventListener('click', () => {
    const isOpen = links.classList.toggle('open');
    toggle.classList.toggle('open');
    toggle.setAttribute('aria-expanded', isOpen);
  });

  // Close mobile menu when a link is clicked
  links.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      links.classList.remove('open');
      toggle.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });

  // --- Active page highlighting ---
  // Get just the filename from the current URL (e.g. "about.html")
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';

  links.querySelectorAll('a').forEach(link => {
    const linkPage = link.getAttribute('href').split('/').pop();
    if (linkPage === currentPage) {
      link.classList.add('active');
    }
  });
}


/**
 * initFooter()
 * ----------------
 * Sets the copyright year to the current year automatically.
 * Called after the footer HTML has been injected.
 */
function initFooter() {
  const yearSpan = document.getElementById('footer-year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
}


/* -----------------------------------------------------------
   BOOT — Load components when the DOM is ready
   ----------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', async () => {
  // Check if opened via file:// protocol
  if (window.location.protocol === 'file:') {
    const warning = document.createElement('div');
    warning.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#ef4444;color:white;padding:16px;text-align:center;z-index:99999;font-family:sans-serif;box-shadow:0 4px 6px rgba(0,0,0,0.1);';
    warning.innerHTML = '<strong>Warning:</strong> You are viewing this site by double-clicking the HTML file (file:// protocol). For security reasons, browsers block loading the navigation and footer components this way. Please use a local web server (e.g., <code style="background:rgba(0,0,0,0.2);padding:2px 6px;border-radius:4px;">npx serve</code> or VS Code Live Server) to view the site correctly.';
    document.body.prepend(warning);
    return; // Stop trying to fetch components
  }

  // Load the navbar, then initialise its toggle behaviour
  await loadComponent('navbar-placeholder', 'components/navbar.html');
  initNavbar();

  // Load the footer, then set the copyright year
  await loadComponent('footer-placeholder', 'components/footer.html');
  initFooter();
});
